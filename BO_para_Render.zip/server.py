"""BO marketplace / catálogo consultivo. Sem pagamentos reais.
Python 3.10+ standard library, SQLite, sem dependências externas.
"""
import os, json, sqlite3, hashlib, hmac, secrets, time, html, re
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from http.cookies import SimpleCookie
from pathlib import Path

BASE=Path(__file__).resolve().parent
DB=Path(os.getenv('BO_DB_PATH',str(BASE/'bo.sqlite3')))
PASSWORD=os.getenv('BO_ADMIN_PASSWORD','')
SECRET=os.getenv('BO_SESSION_SECRET','')
HOST=os.getenv('BO_HOST','127.0.0.1'); PORT=int(os.getenv('PORT','8080'))
COOKIE_SECURE=os.getenv('BO_HTTPS','0')=='1'
if not PASSWORD or not SECRET or len(SECRET)<24:
 raise SystemExit('Configure BO_ADMIN_PASSWORD e BO_SESSION_SECRET (mínimo 24 caracteres) antes de iniciar.')

def db():
 c=sqlite3.connect(str(DB),timeout=15); c.row_factory=sqlite3.Row;return c

def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS works (id INTEGER PRIMARY KEY, artist TEXT NOT NULL, name TEXT NOT NULL, year TEXT, medium TEXT, dimensions TEXT, category TEXT, price REAL, availability TEXT NOT NULL DEFAULT "unconfirmed", image TEXT, description TEXT, page INTEGER)')
  c.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS inquiries (id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT UNIQUE, name TEXT, contact TEXT, notes TEXT, items TEXT, status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)')
  if c.execute('SELECT count(*) FROM works').fetchone()[0]==0:
   for w in json.loads((BASE/'catalog_seed.json').read_text()):
    c.execute('INSERT INTO works (id,artist,name,year,medium,dimensions,category,price,availability,image,description,page) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',tuple(w.get(k) for k in ['id','artist','name','year','medium','dimensions','category','price','availability','image','description','page']))
  # A obra pertence documentalmente ao projeto; venda é escopo comercial separado.
  # Ao atualizar bancos existentes, todas as 50 fichas deste catálogo continuam como PROJETO.
  cols={r[1] for r in c.execute('PRAGMA table_info(works)')}
  if 'placement' not in cols:c.execute("ALTER TABLE works ADD COLUMN placement TEXT NOT NULL DEFAULT 'project'")
  if 'project_slug' not in cols:c.execute("ALTER TABLE works ADD COLUMN project_slug TEXT DEFAULT 'enoque'")
  c.execute("UPDATE works SET placement='project' WHERE placement IS NULL OR placement='' ")
  c.execute('''CREATE TABLE IF NOT EXISTS projects (
       slug TEXT PRIMARY KEY, title TEXT NOT NULL, curator TEXT,
       start_date TEXT, end_date TEXT, cover_image TEXT,
       status TEXT NOT NULL DEFAULT 'encerrado', essay_slug TEXT,
       is_featured INTEGER NOT NULL DEFAULT 0)''')
  project_cols={r[1] for r in c.execute('PRAGMA table_info(projects)')}
  if 'essay_text' not in project_cols:c.execute("ALTER TABLE projects ADD COLUMN essay_text TEXT DEFAULT ''")
  if c.execute('SELECT count(*) FROM projects').fetchone()[0]==0:
   for pr in json.loads((BASE/'projects_seed.json').read_text()):
    c.execute('INSERT INTO projects(slug,title,curator,start_date,end_date,cover_image,status,essay_slug,is_featured) VALUES (?,?,?,?,?,?,?,?,?)',
      (pr['slug'],pr['title'],pr.get('curator',''),pr.get('start',''),pr.get('end',''),pr.get('cover_image',''),pr.get('status','encerrado'),pr.get('essay_slug',''),int(pr.get('is_featured',False))))

MIMES={'.html':'text/html; charset=utf-8','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.css':'text/css','.js':'application/javascript'}
class Handler(BaseHTTPRequestHandler):
 def send(self,code,content,ctype='text/html; charset=utf-8',headers=None):
  if isinstance(content,str):content=content.encode('utf-8')
  self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(content)))
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
  self.send_header('X-Frame-Options','DENY')
  self.send_header('Cache-Control','no-store' if '/api/' in self.path or '/admin' in self.path else 'public, max-age=3600')
  for k,v in (headers or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(content)
 def json(self,code,payload):self.send(code,json.dumps(payload,ensure_ascii=False),'application/json; charset=utf-8')
 def payload(self):
  n=int(self.headers.get('Content-Length','0'))
  if n<=0 or n>65536:raise ValueError('Tamanho inválido')
  raw=self.rfile.read(n); ct=self.headers.get('Content-Type','')
  if 'application/json' in ct:return json.loads(raw)
  return {k:v[0] for k,v in parse_qs(raw.decode()).items()}
 def auth_token(self):
  try:
   c=SimpleCookie();c.load(self.headers.get('Cookie',''));return c['bo_admin'].value
  except Exception:return ''
 def authenticated(self):
  token=self.auth_token()
  try:
   ts,nonce,signature=token.split('.')
   if time.time()-int(ts)>28800 or int(ts)>time.time()+60:return False
   expected=hmac.new(SECRET.encode(),f'{ts}.{nonce}'.encode(),hashlib.sha256).hexdigest()
   return hmac.compare_digest(signature,expected)
  except Exception:return False
 def csrf(self):return hmac.new(SECRET.encode(),self.auth_token().encode(),hashlib.sha256).hexdigest()
 def require_admin(self,posted=None):
  if not self.authenticated():self.json(401,{'error':'Acesso restrito'});return False
  if posted is not None and (not hmac.compare_digest(str(posted.get('csrf','')),self.csrf())):
   self.json(403,{'error':'Proteção CSRF'});return False
  return True
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/':return self.send(200,(BASE/'index.html').read_bytes())
  if path.startswith('/static/'):
   f=(BASE/path.lstrip('/')).resolve()
   if not f.is_relative_to((BASE/'static').resolve()) or not f.is_file():return self.send(404,'Não encontrado')
   return self.send(200,f.read_bytes(),MIMES.get(f.suffix,'application/octet-stream'))
  if path=='/health':return self.json(200,{'status':'ok'})
  if path=='/api/instagram':
   # Requer conta Criador autorizada e token obtido via login oficial da Meta.
   # Tokens são configurados no servidor, nunca expostos no HTML.
   token=os.getenv('BO_IG_ACCESS_TOKEN','')
   ig_user_id=os.getenv('BO_IG_USER_ID','')
   if not token or not ig_user_id:return self.json(200,{'items':[],'connected':False})
   try:
    import urllib.request,urllib.parse
    params=urllib.parse.urlencode({'fields':'id,caption,media_type,media_url,thumbnail_url,permalink,timestamp','limit':'9','access_token':token})
    url=f'https://graph.instagram.com/{urllib.parse.quote(ig_user_id,safe="")}/media?{params}'
    request=urllib.request.Request(url,headers={'User-Agent':'BO-Marketplace/1.0'})
    with urllib.request.urlopen(request,timeout=8) as response:
     payload=json.load(response)
    items=[{k:it.get(k) for k in ['id','caption','media_type','media_url','thumbnail_url','permalink','timestamp']} for it in payload.get('data',[]) if it.get('permalink')]
    return self.json(200,{'items':items,'connected':True})
   except Exception:
    return self.json(200,{'items':[],'connected':False})
  if path=='/api/editorial':
   with db() as c:row=c.execute('SELECT value FROM settings WHERE key=?',('video_url',)).fetchone()
   return self.json(200,{'video_url':row['value'] if row else ''})
  if path=='/api/projects':
   with db() as c:rows=[dict(x) for x in c.execute('SELECT * FROM projects ORDER BY is_featured DESC,start_date DESC')]
   return self.json(200,rows)
  if path=='/api/works':
   with db() as c:rows=[dict(x) for x in c.execute('SELECT * FROM works ORDER BY id')]
   return self.json(200,rows)
  if path=='/admin':return self.send(200,admin_page(self.authenticated(),self.csrf() if self.authenticated() else ''))
  if path=='/api/admin/inquiries':
   if not self.require_admin():return
   with db() as c:rows=[dict(x) for x in c.execute('SELECT * FROM inquiries ORDER BY id DESC LIMIT 1000')]
   return self.json(200,rows)
  return self.send(404,'Não encontrado')
 def do_POST(self):
  path=urlparse(self.path).path
  try:p=self.payload()
  except Exception:return self.json(400,{'error':'Dados inválidos'})
  if path=='/api/admin/login':
   candidate=str(p.get('password',''))
   if not hmac.compare_digest(candidate,PASSWORD):
    time.sleep(.5);return self.json(403,{'error':'Senha incorreta'})
   ts=str(int(time.time()));nonce=secrets.token_hex(16);msg=f'{ts}.{nonce}'
   signature=hmac.new(SECRET.encode(),msg.encode(),hashlib.sha256).hexdigest()
   cookie=f'bo_admin={msg}.{signature}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+('; Secure' if COOKIE_SECURE else '')
   return self.send(303,b'',headers={'Set-Cookie':cookie,'Location':'/admin'})
  if path=='/api/admin/logout':
   return self.send(303,b'',headers={'Set-Cookie':'bo_admin=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict','Location':'/admin'})
  if path=='/api/inquiries':
   name=str(p.get('name','')).strip()[:150]; contact=str(p.get('contact','')).strip()[:180]; notes=str(p.get('notes','')).strip()[:2000]; ids=p.get('items',[])
   if not name or not contact or len(name)<2 or not isinstance(ids,list) or not (1<=len(ids)<=30) or not all(isinstance(x,int) for x in ids):return self.json(400,{'error':'Informe nome, contato e obras.'})
   ids=list(dict.fromkeys(ids))
   with db() as c:
    works=[dict(x) for x in c.execute('SELECT id,artist,name,price,availability,placement,project_slug FROM works WHERE id IN ('+','.join('?'*len(ids))+')',ids)]
    if len(works)!=len(ids) or any(w['placement']!='acervo' or w['availability']!='available' for w in works):return self.json(409,{'error':'Há obras vinculadas a projetos, não disponíveis ou não autorizadas no Acervo. Atualize sua seleção.'})
    ref='BO-'+time.strftime('%Y%m%d')+'-'+secrets.token_hex(3).upper()
    c.execute('INSERT INTO inquiries(reference,name,contact,notes,items,status) VALUES (?,?,?,?,?,?)',(ref,name,contact,notes,json.dumps(works,ensure_ascii=False),'new'))
   return self.json(201,{'reference':ref,'message':'Consulta registrada. Não é uma compra.'})
  if path=='/api/admin/editorial':
   if not self.require_admin(p):return
   url=str(p.get('video_url','')).strip()
   if len(url)>2048 or (url and (not url.startswith('https://') or not re.search(r'\.mp4(?:[?#]|$)',url,re.I))):return self.json(400,{'error':'Informe um link HTTPS direto para arquivo MP4'})
   with db() as c:c.execute('INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)',('video_url',url))
   return self.json(200,{'ok':True})
  if path=='/api/admin/work/new':
   if not self.require_admin(p):return
   try:
    artist=str(p.get('artist','')).strip()[:160]
    name=str(p.get('name','')).strip()[:220]
    if not artist or not name:raise ValueError('Artista e título são obrigatórios')
    year=str(p.get('year','')).strip()[:30]
    medium=str(p.get('medium','')).strip()[:400]
    dimensions=str(p.get('dimensions','')).strip()[:120]
    category=str(p.get('category','Pinturas')).strip()[:80]
    image=str(p.get('image','')).strip()[:500]
    if not image or not (image.startswith('/static/img/') or image.startswith('https://')):raise ValueError('Use uma imagem HTTPS ou /static/img/')
    project_slug=str(p.get('project_slug','')).strip()[:80]
    with db() as c:
     pr=c.execute('SELECT slug FROM projects WHERE slug=?',(project_slug,)).fetchone()
     if not pr:raise ValueError('Escolha um projeto cadastrado')
     cur=c.execute('INSERT INTO works(artist,name,year,medium,dimensions,category,price,availability,image,description,page,placement,project_slug) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
      (artist,name,year,medium,dimensions,category,None,'unconfirmed',image,'Obra cadastrada no projeto',None,'project',project_slug))
    return self.json(201,{'ok':True,'id':cur.lastrowid})
   except (ValueError,TypeError) as e:return self.json(400,{'error':str(e)})
  if path=='/api/admin/work':
   if not self.require_admin(p):return
   try:
    id=int(p['id']); price=None if str(p.get('price','')).strip()=='' else float(p['price'])
    if price is not None and (price<0 or price>1e10):raise ValueError()
    availability=p['availability']
    if availability not in ('unconfirmed','available','reserved','sold'):raise ValueError()
    placement=str(p.get('placement','project'))
    if placement not in ('project','acervo','returned'):raise ValueError()
    project_slug=str(p.get('project_slug','enoque')).strip()[:80]
    with db() as c:
     current=c.execute('SELECT placement,project_slug FROM works WHERE id=?',(id,)).fetchone()
     if not current:return self.json(404,{'error':'Obra não encontrada'})
     pr=c.execute('SELECT status FROM projects WHERE slug=?',(project_slug,)).fetchone() if project_slug else None
     if placement=='acervo':
      if not pr or pr['status']!='encerrado':return self.json(409,{'error':'Para mover ao Acervo, finalize o projeto e aprove a transferência manualmente.'})
     cur=c.execute('UPDATE works SET price=?,availability=?,placement=?,project_slug=? WHERE id=?',(price,availability,placement,project_slug,id))
     if cur.rowcount==0:return self.json(404,{'error':'Obra não encontrada'})
    return self.json(200,{'ok':True})
   except (KeyError,ValueError,TypeError):return self.json(400,{'error':'Preço/disponibilidade inválidos'})
  if path=='/api/admin/project':
   if not self.require_admin(p):return
   try:
    slug=str(p.get('slug','')).strip().lower()
    if not re.fullmatch(r'[a-z0-9-]{3,60}',slug):raise ValueError('Identificador inválido')
    title=str(p.get('title','')).strip()[:180]
    if not title:raise ValueError('Informe o título')
    status=str(p.get('status','encerrado'))
    if status not in ('futuro','em_cartaz','encerrado'):raise ValueError('Status inválido')
    curator=str(p.get('curator','')).strip()[:180]
    start_date=str(p.get('start_date','')).strip()[:10]
    end_date=str(p.get('end_date','')).strip()[:10]
    cover_image=str(p.get('cover_image','')).strip()[:400]
    if cover_image and not (cover_image.startswith('/static/') or cover_image.startswith('https://')):raise ValueError('Imagem deve ser HTTPS ou /static/')
    essay_text=str(p.get('essay_text','')).strip()[:24000]
    featured=int(bool(p.get('is_featured',False)))
    with db() as c:
     if featured:c.execute('UPDATE projects SET is_featured=0')
     c.execute('''INSERT INTO projects(slug,title,curator,start_date,end_date,cover_image,status,essay_slug,is_featured,essay_text)
       VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(slug) DO UPDATE SET
       title=excluded.title,curator=excluded.curator,start_date=excluded.start_date,end_date=excluded.end_date,
       cover_image=excluded.cover_image,status=excluded.status,essay_slug=excluded.essay_slug,is_featured=excluded.is_featured,essay_text=excluded.essay_text''',
       (slug,title,curator,start_date,end_date,cover_image,status,slug,featured,essay_text))
    return self.json(200,{'ok':True})
   except (ValueError,TypeError) as e:return self.json(400,{'error':str(e)})
  if path=='/api/admin/inquiry':
   if not self.require_admin(p):return
   try:
    id=int(p['id']);status=p['status'];assert status in ('new','contacted','closed')
    with db() as c:c.execute('UPDATE inquiries SET status=? WHERE id=?',(status,id))
    return self.json(200,{'ok':True})
   except Exception:return self.json(400,{'error':'Status inválido'})
  return self.send(404,'Não encontrado')

def admin_page(authed,csrf):
 if not authed:return '''<!doctype html><html lang="pt-br"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>BO — Acesso</title><style>body{font:16px Arial;background:#f9f8f4;max-width:450px;margin:12vh auto;padding:24px}input,button{font:inherit;padding:14px;width:100%;margin:12px 0;border:1px solid #aaa}button{background:#111;color:white}</style><h1>BO / Administração</h1><p>Acesso restrito à equipe.</p><form method="post" action="/api/admin/login"><input required type="password" name="password" placeholder="Senha de administração"><button>Entrar</button></form><a href="/">Voltar ao acervo</a></html>'''
 return ADMIN.replace('__CSRF__',csrf)

ADMIN='''<!doctype html><html lang="pt-br"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BO | Administração</title><style>body{font:14px Arial;background:#faf9f6;color:#161616;margin:0;padding:30px}header{display:flex;justify-content:space-between;align-items:center;gap:20px}h1{font-size:44px}table{border-collapse:collapse;width:100%;background:#fff}td,th{border-bottom:1px solid #ddd;padding:10px;text-align:left}input,select,button{font:inherit;padding:8px;border:1px solid #aaa;background:#fff}button{cursor:pointer}button.primary{background:#161616;color:#fff}img{width:50px;height:65px;object-fit:contain}.wrap{overflow-x:auto}section{margin-top:40px}.muted{color:#777}#notice{min-height:24px}</style><header><h1>BO / Gestão</h1><form method="post" action="/api/admin/logout"><button>Sair</button></form></header><p>Preços de referência do catálogo. Confirme direitos, disponibilidade, preços e frete antes da comercialização.</p><p id="notice" role="status"></p><section><h2>Vídeo institucional — página inicial</h2><p>Informe a URL HTTPS direta de um MP4 hospedado externamente. Para retirar o vídeo, deixe o campo em branco e salve.</p><input id="institutionalVideo" type="url" style="width:min(600px,90%)" placeholder="https://dominio.com/bo.mp4"><button class="primary" onclick="saveEditorial()">Salvar vídeo</button></section><section><h2>Projetos</h2><p>Somente projetos encerrados podem ter obras transferidas explicitamente ao Acervo. O encerramento nunca transfere automaticamente.</p>
<div id="projectManager"></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:15px 0"><input id="prSlug" placeholder="Identificador (ex.: exposicao-2027)"><input id="prTitle" placeholder="Título"><input id="prCurator" placeholder="Curadoria"><input id="prStart" type="date" aria-label="Data início"><input id="prEnd" type="date" aria-label="Data fim"><input id="prCover" placeholder="Imagem /static/img/... ou https://..."><textarea id="prEssay" placeholder="Texto para o Caderno (opcional)" rows="4"></textarea><select id="prStatus"><option value="futuro">Futuro</option><option value="em_cartaz">Em cartaz</option><option value="encerrado">Encerrado</option></select><label><input id="prFeatured" type="checkbox"> Destaque na home</label></div><button class="primary" onclick="saveProject()">Salvar projeto</button></section><section><h2>Cadastrar obra no projeto</h2><p>Ao cadastrar, a obra entra somente no Projeto, sem preço ou opção de compra. Envie uma URL segura da fotografia.</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin:12px 0"><input id="nwArtist" placeholder="Artista"><input id="nwName" placeholder="Título da obra"><input id="nwYear" placeholder="Ano"><input id="nwMedium" placeholder="Técnica / material"><input id="nwDimensions" placeholder="Dimensões"><input id="nwCategory" placeholder="Categoria"><input id="nwImage" placeholder="https://... ou /static/img/..."><select id="nwProject" aria-label="Projeto"></select></div>
<button class="primary" onclick="createWork()">Cadastrar obra</button></section><section><h2>Obras</h2><div class="wrap"><table><thead><tr><th>Imagem</th><th>Artista / obra</th><th>Preço (R$)</th><th>Disponibilidade</th><th>Área</th><th>Projeto</th><th>Salvar</th></tr></thead><tbody id="works"></tbody></table></div></section><section><h2>Consultas recebidas</h2><div class="wrap"><table><thead><tr><th>Referência</th><th>Cliente</th><th>Contato</th><th>Peças</th><th>Observações</th><th>Status</th></tr></thead><tbody id="inquiries"></tbody></table></div></section><script>
const csrf='__CSRF__';const esc=t=>String(t??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statuses=['unconfirmed','available','reserved','sold'];
const names={unconfirmed:'A confirmar',available:'Disponível',reserved:'Reservada',sold:'Vendida'};
async function post(url,body){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,csrf})});const d=await r.json();if(!r.ok)throw Error(d.error);return d;}
async function load(){try{
const [a,b,v,z]=await Promise.all([fetch('/api/works'),fetch('/api/admin/inquiries'),fetch('/api/editorial'),fetch('/api/projects')]);const works=await a.json();const inquiries=await b.json();const video=await v.json();const projects=await z.json();window.boAdminProjects=projects;document.getElementById('nwProject').innerHTML=projects.map(pr=>`<option value="${esc(pr.slug)}">${esc(pr.title)}</option>`).join('');document.getElementById('projectManager').innerHTML=projects.map(p=>`<p><b>${esc(p.title)}</b> · ${esc(p.status)} · ${esc(p.start_date)} até ${esc(p.end_date)} <button onclick="editProject('${esc(p.slug)}')">Editar</button></p>`).join('');document.getElementById('institutionalVideo').value=video.video_url||'';
document.getElementById('works').innerHTML=works.map(w=>`<tr><td><img src="${esc(w.image)}"></td><td><b>${esc(w.artist)}</b><br>${esc(w.name)}</td><td><input aria-label="Preço" id="price${w.id}" type="number" min="0" step="0.01" value="${w.price??''}"></td><td><select id="status${w.id}">${statuses.map(v=>`<option value="${v}" ${v===w.availability?'selected':''}>${names[v]}</option>`).join('')}</select></td><td><select id="placement${w.id}">${['project','returned','acervo'].map(v=>`<option value="${v}" ${v===w.placement?'selected':''}>${{project:'Projeto',returned:'Devolvida',acervo:'Acervo'}[v]}</option>`).join('')}</select></td><td><select id="projectSlug${w.id}">${projects.map(pr=>`<option value="${esc(pr.slug)}" ${pr.slug===w.project_slug?'selected':''}>${esc(pr.title)}</option>`).join('')}</select></td><td><button class="primary" onclick="save(${w.id})">Salvar</button></td></tr>`).join('');
document.getElementById('inquiries').innerHTML=inquiries.map(q=>{let items=[];try{items=JSON.parse(q.items)}catch(e){}return `<tr><td>${esc(q.reference)}<br><small>${esc(q.created_at)}</small></td><td>${esc(q.name)}</td><td>${esc(q.contact)}</td><td>${items.map(x=>esc(x.artist)+' — '+esc(x.name)).join('<hr>')}</td><td>${esc(q.notes)}</td><td><select onchange="setStatus(${q.id},this.value)">${['new','contacted','closed'].map(v=>`<option ${v===q.status?'selected':''} value="${v}">${v}</option>`).join('')}</select></td></tr>`}).join('')||'<tr><td colspan="6">Nenhuma consulta recebida.</td></tr>';
}catch(e){notice.textContent='Erro: '+e.message}}
async function saveEditorial(){try{await post('/api/admin/editorial',{video_url:document.getElementById('institutionalVideo').value.trim()});notice.textContent='Vídeo institucional atualizado.'}catch(e){notice.textContent=e.message}}
async function save(id){try{await post('/api/admin/work',{id,price:document.getElementById('price'+id).value,availability:document.getElementById('status'+id).value,placement:document.getElementById('placement'+id).value,project_slug:document.getElementById('projectSlug'+id).value});notice.textContent='Obra '+id+' atualizada.'}catch(e){notice.textContent=e.message}}
async function setStatus(id,status){try{await post('/api/admin/inquiry',{id,status});notice.textContent='Consulta atualizada.'}catch(e){notice.textContent=e.message}}
async function createWork(){try{const g=id=>document.getElementById(id).value.trim();await post('/api/admin/work/new',{artist:g('nwArtist'),name:g('nwName'),year:g('nwYear'),medium:g('nwMedium'),dimensions:g('nwDimensions'),category:g('nwCategory'),image:g('nwImage'),project_slug:g('nwProject')});notice.textContent='Obra cadastrada em Projeto, sem venda.';await load()}catch(e){notice.textContent=e.message}}
function editProject(slug){const p=(window.boAdminProjects||[]).find(x=>x.slug===slug);if(!p)return;for(const [field,val] of [['prSlug',p.slug],['prTitle',p.title],['prCurator',p.curator],['prStart',p.start_date],['prEnd',p.end_date],['prCover',p.cover_image],['prStatus',p.status],['prEssay',p.essay_text]])document.getElementById(field).value=val||'';document.getElementById('prFeatured').checked=!!p.is_featured;window.scrollTo({top:0,behavior:'smooth'})}
async function saveProject(){try{await post('/api/admin/project',{slug:prSlug.value,title:prTitle.value,curator:prCurator.value,start_date:prStart.value,end_date:prEnd.value,cover_image:prCover.value,essay_text:prEssay.value,status:prStatus.value,is_featured:prFeatured.checked});notice.textContent='Projeto salvo.';await load()}catch(e){notice.textContent='Erro no projeto: '+e.message}}
load();</script></html>'''

if __name__=='__main__':
 init();print(f'BO no endereço http://{HOST}:{PORT}');ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
