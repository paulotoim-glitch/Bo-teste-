# BO — site e gestão de acervo

Projeto do marketplace BO com identidade visual aprovada, catálogo de 50 obras extraído do PDF *Enoque vai ao centro da Terra*, painel administrativo e registro de consultas.

## Executar

Requer **Python 3.10+**, sem bibliotecas extras.

```bash
export BO_ADMIN_PASSWORD='defina-uma-senha-forte'
export BO_SESSION_SECRET='defina-um-segredo-aleatorio-com-pelo-menos-24-caracteres'
python3 server.py
```

Abra `http://127.0.0.1:8080` e o painel em `/admin`.

Para testar numa rede local, defina `BO_HOST=0.0.0.0`. **Não publique diretamente esse servidor de desenvolvimento na internet.** Para publicação, use um serviço de hospedagem gerenciado com HTTPS, proxy reverso, autenticação robusta, proteção contra abuso, backups e revisão técnica de segurança. Defina `BO_HTTPS=1` sob HTTPS.

## O que funciona

- 50 fotografias reais do catálogo, fichas e valores de referência.
- Grade de acervo e páginas de obra com identidade da BO.
- Preços e status centralizados em SQLite (`bo.sqlite3`, criado na primeira execução).
- Painel `/admin` com senha para alterar preços e status, e ler consultas recebidas.
- Pedido **de consulta**, sem pagamento, gravado no banco com referência BO e disponibilizado no painel.
- Obras vendidas não podem ser solicitadas no servidor.

## O que falta para venda pública

1. **Confirmar direitos de uso das imagens, textos e obras**, autorização para uso comercial e disponibilidade real de cada peça.
2. Revisar preços, tributação, faturamento, dados da empresa, privacidade/LGPD e política de troca/devolução aplicável.
3. Escolher e ativar um provedor de pagamentos e meios de entrega compatíveis com a operação, com confirmação de transações por webhook e proteção contra vendas simultâneas de obras únicas.
4. Contratar domínio, HTTPS, hospedagem persistente, backups e e-mail de atendimento.
5. Reforçar o backend para produção (autenticação e gerenciamento de usuários, limitação de requisições, CSRF e proteções adicionais, auditoria, anti-spam, monitoramento, termos de serviço).

Não existem cobranças reais, pagamentos, cálculo de frete, notificações automáticas de e-mail nem reserva efetiva; consultas ficam armazenadas no banco para tratamento da equipe.

## Estrutura
- `index.html`: interface gráfica aprovada.
- `static/img/`: imagens do catálogo e logotipos originais.
- `catalog_seed.json`: base de importação inicial.
- `server.py`: servidor de demonstração, banco de dados, painel e consultas.

> Importante: as fotografias no catálogo são referências da mostra *Enoque vai ao centro da Terra* e não significam que estas obras tenham sido autorizadas para venda pela BO.

## Recurso Perspectiva
- Botão **PERSPECTIVA — VER EM ESCALA** em cada ficha de obra.
- A partir de duas medidas em centímetros, compara proporcionalmente altura e largura da peça com uma pessoa de 170 cm ou cadeira de 85 cm.
- A primeira medida é interpretada inicialmente como altura; use **Inverter altura e largura** quando o catálogo registrar largura primeiro.
- Em esculturas e cerâmicas a imagem é uma **vista frontal ilustrativa**, sem simulação 3D de profundidade.
- Ausência de medidas bloqueia a comparação e pede revisão da ficha.
- IMPORTANTE: o preview não garante percepção exata, nem substitui foto de instalação calibrada. Confirmar dimensões, orientação e qualidade do recorte da imagem antes de publicação.


## Seção LINA NA BAHIA (versão 6)
- A página inicial inclui seção editorial com feed do Instagram e vídeo exclusivamente na home.
- O feed é carregado por `GET /api/instagram`. Sem credenciais, retorna vazio (não inventa publicações).
- Para conectar a conta Criador autorizada, configure `BO_IG_ACCESS_TOKEN` e `BO_IG_USER_ID` no servidor, após implementar e validar a concessão oficial de acesso Meta, permissões, renovação de token e política de privacidade. A disponibilidade de endpoints depende do produto Meta habilitado e pode exigir ajuste.
- O campo de URL MP4 é apenas **prévia local do navegador**; não publica conteúdo para visitantes. O cadastro definitivo de vídeo exige armazenamento/painel no servidor.
- A seção vídeo só aparece na home. As fichas das obras mantêm o recurso Perspectiva.

## Versão 9 — vídeo institucional centralizado
- O vídeo continua **somente no rodapé da página inicial**. O Instagram @linanabahia fica no alto.
- A equipe pode cadastrar o endereço HTTPS direto de um MP4 em `/admin` > **Vídeo institucional**. O URL fica no SQLite e aparece para todos após publicação no servidor.
- URL de vídeo vazia oculta o player e exibe o aviso de vídeo não publicado. Para grandes audiências, hospede o MP4 em CDN/plataforma adequada.
- O feed do Instagram ainda exige integração Meta autorizada; o placeholder atual não representa uma conexão ativa.


### Versão 10: ajustes de layout
Cabeçalho compacto, destaque com obra real, acervo com uma busca/contagem, grade de artistas, Instagram perto do rodapé e painel sem link público. Reimplantar a versão revisada no repositório GitHub; o site público não se atualiza automaticamente apenas baixando este ZIP.


## Atualização v15
Índice de 32 artistas compacto, sem setas; links e páginas individuais preservados.

## Versão 17
- A imagem de destaque de Daniel Barreto está incorporada diretamente no HTML para abrir também na prévia local. Toque na imagem ou no título para abrir a ficha da obra.
- Foram removidas as setas gráficas de botões, links e chamadas, preservando seus cliques.


Versão 18: tipografia dos links e notas do rodapé uniformizada em 12px, inclusive Contato · @nnd_azeco.


## Revisão v19 — acabamento
- Ajustado enquadramento da obra de destaque em telas pequenas, sem área preta vazia acima da fotografia.
- Fichas, sacola e sobreposições agora aparecem acima do cabeçalho fixo.
- Revisão de espaçamentos do acervo, artistas, Caderno, vídeo institucional e rodapé.
- Mantidos o logotipo original, o botão amarelo, o índice completo de artistas sem setas e o recurso Perspectiva.
- Removidos o banner superior redundante e a chamada numérica decorativa. O aviso de protótipo permanece no rodapé.
- Corrigido o crédito Gerben Mulder, coerente com o catálogo de artistas do projeto.
- Verificações automatizadas de interface em largura de celular e desktop; não substituem testes no site público.


## Versão 20 — revisão integral das 50 imagens
- Substituídas todas as 50 imagens do acervo por fotografias inteiras extraídas do PDF original, sem o recorte anterior. O recorte era feito na imagem de origem, portanto CSS sozinho não bastava.
- A obra de Andy Villela volta a mostrar a composição inteira, incluindo a parte inferior azul; os trabalhos de Ariano Suassuna mantêm as molduras completas.
- Corrigida a cor dos links do menu, antes invisíveis (texto branco em fundo claro).
- Página principal e fichas utilizam object-fit: contain, preservando proporções e bordas.
- Valores, disponibilidade e pedidos permanecem demonstrativos até a validação comercial.

## Versão 21 — Projeto e Acervo são áreas diferentes

- **Projeto** vem antes de Acervo na home e no menu. A home exibe uma imagem, título, curadoria e período da exposição. A página individual oferece imagem grande, obras participantes, texto vinculado ao Caderno e arquivo de exposições anteriores.
- A exposição **Enoque vai ao centro da Terra** foi usada como primeiro exemplo do sistema, com créditos retirados do catálogo: **Curadoria de Bertô; texto crítico de Thaís Bambozzi**. O período 22/08/2026–03/10/2026 deve ser confirmado na revisão editorial antes do lançamento definitivo.
- **As 50 obras do PDF são inicialmente classificadas como `project`**: por isso não aparecem no Acervo comercial, não mostram preço na ficha do projeto e **não podem ser enviadas em consultas comerciais**. O servidor também bloqueia essas tentativas.
- Obras devolvidas podem ser marcadas `returned`. A participação histórica no projeto permanece visível, mas não gera comércio.
- **Apenas a equipe** pode transferir manualmente uma peça ao Acervo; só é permitido se o projeto estiver marcado como encerrado. A transferência não é automática.
- No painel `/admin`, é possível criar novos projetos com título, curadoria, datas, fotografia, status e texto editorial; cadastrar obras vinculadas; e gerenciar disponibilidades.
- Projetos anteriores aparecem como cards **quando cadastrados**. Sem dados fornecidos, o sistema não inventa exposições para preencher o arquivo.
- Imagens para novos cadastros devem estar em `/static/img/` ou num endereço HTTPS válido. O upload direto de fotografias ao servidor ainda não está implementado.

### Dados de teste e publicação

**Não atualize o Render antes da aprovação visual e comercial.** Se o banco existente for efêmero (plano gratuito Render), qualquer edição no painel pode se perder após reinstalações e reinícios: migre para uma base persistente antes da operação real.

A versão 21 preserva a marca BO, Perspectiva, vídeo editorial somente na home e layout claro do acervo, sem ativar cobrança de clientes.

## Versão 22 — marca e alinhamento
Nova marca de arquivo IMG_2066.png aplicada no cabeçalho, rodapé, scripts e favicon; eixo esquerdo unificado em toda a interface. Não modifica preços, acervo ou status de obras.


## Versão 24 — sangria da marca no rodapé
- Logomarca encostada exatamente na borda superior do bloco claro do rodapé, sem espaço branco acima.
- Margem esquerda preservada no mesmo eixo dos títulos e botões.
- Textos do rodapé mantêm espaçamento próprio. Identidade, imagens, menu, Projetos e Acervo sem alterações.
