# BO — site e gestão de acervo

Projeto do marketplace BO com identidade visual aprovada, catálogo de 50 obras extraído do PDF *Enoque vai ao centro da Terra*, painel administrativo e registro de consultas.

## Executar

Requer **Python 3.10+**, sem bibliotecas extras.

```bash
export BO_ADMIN_PASSWORD='defina-uma-senha-forte'
export BO_SESSION_SECRET='defina-um-segredo-aleatorio-com-pelo-menos-24-caracteres'
python3 server.py
```

Abra `http://127.0.0.1:8080` e o painel em `/admin`.

Para testar numa rede local, defina `BO_HOST=0.0.0.0`. **Não publique diretamente esse servidor de desenvolvimento na internet.** Para publicação, use um serviço de hospedagem gerenciado com HTTPS, proxy reverso, autenticação robusta, proteção contra abuso, backups e revisão técnica de segurança. Defina `BO_HTTPS=1` sob HTTPS.

## O que funciona

- 50 fotografias reais do catálogo, fichas e valores de referência.
- Grade de acervo e páginas de obra com identidade da BO.
- Preços e status centralizados em SQLite (`bo.sqlite3`, criado na primeira execução).
- Painel `/admin` com senha para alterar preços e status, e ler consultas recebidas.
- Pedido **de consulta**, sem pagamento, gravado no banco com referência BO e disponibilizado no painel.
- Obras vendidas não podem ser solicitadas no servidor.

## O que falta para venda pública

1. **Confirmar direitos de uso das imagens, textos e obras**, autorização para uso comercial e disponibilidade real de cada peça.
2. Revisar preços, tributação, faturamento, dados da empresa, privacidade/LGPD e política de troca/devolução aplicável.
3. Escolher e ativar um provedor de pagamentos e meios de entrega compatíveis com a operação, com confirmação de transações por webhook e proteção contra vendas simultâneas de obras únicas.
4. Contratar domínio, HTTPS, hospedagem persistente, backups e e-mail de atendimento.
5. Reforçar o backend para produção (autenticação e gerenciamento de usuários, limitação de requisições, CSRF e proteções adicionais, auditoria, anti-spam, monitoramento, termos de serviço).

Não existem cobranças reais, pagamentos, cálculo de frete, notificações automáticas de e-mail nem reserva efetiva; consultas ficam armazenadas no banco para tratamento da equipe.

## Estrutura
- `index.html`: interface gráfica aprovada.
- `static/img/`: imagens do catálogo e logotipos originais.
- `catalog_seed.json`: base de importação inicial.
- `server.py`: servidor de demonstração, banco de dados, painel e consultas.

> Importante: as fotografias no catálogo são referências da mostra *Enoque vai ao centro da Terra* e não significam que estas obras tenham sido autorizadas para venda pela BO.

## Recurso Perspectiva
- Botão **PERSPECTIVA — VER EM ESCALA** em cada ficha de obra.
- A partir de duas medidas em centímetros, compara proporcionalmente altura e largura da peça com uma pessoa de 170 cm ou cadeira de 85 cm.
- A primeira medida é interpretada inicialmente como altura; use **Inverter altura e largura** quando o catálogo registrar largura primeiro.
- Em esculturas e cerâmicas a imagem é uma **vista frontal ilustrativa**, sem simulação 3D de profundidade.
- Ausência de medidas bloqueia a comparação e pede revisão da ficha.
- IMPORTANTE: o preview não garante percepção exata, nem substitui foto de instalação calibrada. Confirmar dimensões, orientação e qualidade do recorte da imagem antes de publicação.


## Seção LINA NA BAHIA (versão 6)
- A página inicial inclui seção editorial com feed do Instagram e vídeo exclusivamente na home.
- O feed é carregado por `GET /api/instagram`. Sem credenciais, retorna vazio (não inventa publicações).
- Para conectar a conta Criador autorizada, configure `BO_IG_ACCESS_TOKEN` e `BO_IG_USER_ID` no servidor, após implementar e validar a concessão oficial de acesso Meta, permissões, renovação de token e política de privacidade. A disponibilidade de endpoints depende do produto Meta habilitado e pode exigir ajuste.
- O campo de URL MP4 é apenas **prévia local do navegador**; não publica conteúdo para visitantes. O cadastro definitivo de vídeo exige armazenamento/painel no servidor.
- A seção vídeo só aparece na home. As fichas das obras mantêm o recurso Perspectiva.

## Versão 9 — vídeo institucional centralizado
- O vídeo continua **somente no rodapé da página inicial**. O Instagram @linanabahia fica no alto.
- A equipe pode cadastrar o endereço HTTPS direto de um MP4 em `/admin` > **Vídeo institucional**. O URL fica no SQLite e aparece para todos após publicação no servidor.
- URL de vídeo vazia oculta o player e exibe o aviso de vídeo não publicado. Para grandes audiências, hospede o MP4 em CDN/plataforma adequada.
- O feed do Instagram ainda exige integração Meta autorizada; o placeholder atual não representa uma conexão ativa.


### Versão 10: ajustes de layout
Cabeçalho compacto, destaque com obra real, acervo com uma busca/contagem, grade de artistas, Instagram perto do rodapé e painel sem link público. Reimplantar a versão revisada no repositório GitHub; o site público não se atualiza automaticamente apenas baixando este ZIP.
